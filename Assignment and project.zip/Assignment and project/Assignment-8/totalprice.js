const fs = require("fs");
let items=JSON.parse(fs.readFileSync(__dirname+'/cart.json'));
let  totalprice = 0;
for(i=0;i<items.lenght;i++){
    totalprice+=((items[i].product_price)*(items[i].product_quantity));
    console.log(items[i].product_price);
}
console.log(`Total price of all the items present is ${totalprice}`);