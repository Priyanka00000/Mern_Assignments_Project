const express = require('express');
const fs = require('fs');
const app = express();
 
const port = 5000;
app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/cart.json');
    })

app.get('/:data',(req,res)=>{
    console.log(req.params);
    const id = req.params.data;
    var cart = JSON.parse(fs.readFileSync("cart.json"));
    cart = cart.filter(cart=>cart.product_id==id);
    res.send(cart);

}) 
   

app.listen(port,()=>{
    console.log(`Server started at port ${port}`);
})
 