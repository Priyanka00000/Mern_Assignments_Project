const table = document.getElementsByTagName('table')[0];
table.tHead.rows[0].style.backgroundColor='lightblue'
table.tBodies[0].rows[0].style.backgroundColor='lightpink'
table.tBodies[0].rows[1].style.backgroundColor='blueviolet'
table.tBodies[0].rows[2].style.backgroundColor='yellow'
table.tBodies[0].rows[3].style.backgroundColor='orange'
console.log(`Even text from 1st row:`)
for(i=1;i<5;i++)
{
    if(i%2!=0){
        console.log(table.tHead.rows[0].cells[i].innerText)
    }
}
console.log(`Even text from 2nd row:`)
for(i=1;i<5;i++)
{
    if(i%2!=0){
        console.log(table.tBodies[0].rows[0].cells[i].innerText)
    }
}
console.log(`Even text from 3rd row:`)
for(i=1;i<5;i++)
{
    if(i%2!=0){
        console.log(table.tBodies[0].rows[1].cells[i].innerText)
    }
}
console.log(`Even text from 4th row:`)
for(i=1;i<5;i++)
{
    if(i%2!=0){
        console.log(table.tBodies[0].rows[2].cells[i].innerText)
    }
}
console.log(`Even text from 5th row:`)
for(i=1;i<5;i++)
{
    if(i%2!=0){
        console.log(table.tBodies[0].rows[3].cells[i].innerText)
    }
}