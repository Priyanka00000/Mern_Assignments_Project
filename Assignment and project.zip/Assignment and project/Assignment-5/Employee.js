let Employee={
    Name:'D.Priyanka',
    email: 'eee.20beca45@gmail.com',
    Phonenumber:'7978438480',
    basic_sal: 175000,
    total_sal:function(){
        const hra=0.15*this.basic_sal;
        const specialallowance=0.20*this.basic_sal;

        var totalSal=(this.basic_sal + hra + specialallowance);
        if(this.basic_sal>40000 && this.basic_sal<50000)
        totalSal=totalSal-(0.10*totalSal);
        if(this.basic_sal>50000 && this.basic_sal<70000)
        totalSal=totalSal-(0.15*totalSal);
        if(this.basic_sal>70000 && this.basic_sal<90000)
        totalSal=totalSal-(0.20*totalSal);
        if(this.basic_sal>80000)
        totalSal=totalSal-(0.30*totalSal);
        return totalSal;
    }
       
}
console.log(Employee.Name);
console.log(Employee.email);
console.log(Employee.Phonenumber);
console.log(Employee.basic_sal);
console.log(Employee.total_sal());


