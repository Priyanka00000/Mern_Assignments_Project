const express = require('express');
const fs = require('fs');
const app = express();
 
const port = 7000;
app.use(express.json())
app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/product.json');
    })
 

app.get('/:data',(req,res)=>{
    console.log(req.params);
    const id = req.params.data;
    var product = JSON.parse(fs.readFileSync("product.json"));
    product = product.filter(product=>product.product_id==id);
    res.send(product);

}) 
app.post('/adddata',(req,res)=>{ 
    console.log(req.body)
    //const product_id = req.body.product_id;
    //const product_name = req.body.product_name;
    //const product_price = req.body.product_price;
    //const product_des = req.body.product_des;
    //const product_img = req.body.product_img;
    const {id,name,price,des,image} = req.body
    let dataarray = JSON.parse(fs.readFileSync('product.json'));
    dataarray = [...dataarray,{product_id:id,product_name:name,product_price:price,
        product_des: des,product_img:image}]
    fs.writeFile('product.json',JSON.stringify(dataarray),(err)=>{
        if(err)
             return res.status(500).json({
                message:"Something went wrong",
                error:err
             })
        return res.status(201).json({
            message:"Product Details Added Successfully",
            details:{product_id:id,product_name:name,product_price:price,
                product_des:des,product_img:image}
        })     
    })
    
})
app.delete('/deletedata/:id',(req,res)=>{
    const  id  = req.params; 
    let dataarray = JSON.parse(fs.readFileSync('product.json'));
    dataarray = dataarray.filter(data=>data.product_id!=id);
    fs.writeFile('product.json',JSON.stringify(dataarray),(err)=>{
        if(err)
             return res.status(500).json({
                message:"Something went wrong",
                error:err
             })
        return res.status(200).json({
            message:"Product details deleted successfully",

        })       
   })
})
 app.put("/updatedata/:id",(req,res)=>{
    const {id} = req.params
    const{product_id,product_name,product_price,
        product_des,product_img}=req.body;
    let dataarray = JSON.parse(fs.readFileSync('product.json'));
    dataarray = dataarray.filter(items=>items.id != id);
    dataarray = [...dataarray,{product_id:product_id,product_name:product_name,product_price:product_price,
        product_des:product_des,product_img:product_img}]
    fs.writeFile('product.json',JSON.stringify(dataarray),(err)=>{
        if(err)
             return res.status(500).json({
                message:"Something went wrong",
                error:err
             })
        return res.status(201).json({
            message:"Product Details updated Successfully",
            details:{product_id:product_id,product_name:product_name,product_price:product_price,
                product_des:product_des}
        })     
    })
        
 })
   

app.listen(port,()=>{
    console.log(`Server started at port ${port}`);
})
