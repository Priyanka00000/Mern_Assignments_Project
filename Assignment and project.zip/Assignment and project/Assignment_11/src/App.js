
import './App.css';
import {Product} from './components/Product';
function App() {
  const product_arr=[
    {
      product_name:"Lays",
        product_img:"https://mishry.com/wp-content/uploads/2021/02/Lays-Chips-Flavors.jpg",
        product_price:"Rs.20"
    },
    {
      product_name:"Realme 6 pro",
        product_img:"https://www.harapanrakyat.com/wp-content/uploads/2020/03/Spesifikasi-HP-Realme-6-Pro-Lengkap-dengan-Harganya-di-Indonesia.jpg",
        product_price:"Rs.18,999"
    },
    {
      product_name:"Dell Inspiron 14",
        product_img:"https://i.ytimg.com/vi/z1BydFwlGPw/maxresdefault.jpg",
        product_price:"Rs.64,480"
    } 
  ]
  return (
    <div className="App">
      <h1>Product List</h1>
      <Product name={product_arr[0].product_name} image={product_arr[0].product_img} price={product_arr[0].product_price}/>
      <Product name={product_arr[1].product_name} image={product_arr[1].product_img} price={product_arr[1].product_price}/>
      <Product name={product_arr[2].product_name} image={product_arr[2].product_img} price={product_arr[2].product_price}/>
 
    </div>
  );
}

export default App;
